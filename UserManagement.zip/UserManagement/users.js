let users = [
    {
        fname: 'Dan',
        lname: 'David',
        email: 'dan@email.com',
        password: 'Qaz123!qaz',
        isLogedIn: false
    },
    {
        fname: 'Tomer',
        lname: 'Regev',
        email: 'tomer@email.com',
        password: 'Tom123!tom',
        isLogedIn: false
    },
    {
        fname: 'Joe',
        lname: 'Moe',
        email: 'joe@email.com',
        password: 'Joe123!joe',
        isLogedIn: false
    },
];


export { users };
